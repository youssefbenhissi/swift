//
//  Cart.swift
//  mini projet sim
//
//  Created by youssef benhissi on 27/11/2020.
//

import SwiftUI

struct Cart: Identifiable{
    var id = UUID().uuidString
    var plat : Plat
    var quantity: Int
    
}
