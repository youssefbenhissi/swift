//
//  RestaurantList.swift
//  mini projet sim
//
//  Created by youssef benhissi on 08/12/2020.
//

import SwiftUI

struct RestaurantList: View {
    @ObservedObject var obs = observer()
    var body: some View {
        
    }
    }


struct RestaurantList_Previews: PreviewProvider {
    static var previews: some View {
        RestaurantList()
    }
}
